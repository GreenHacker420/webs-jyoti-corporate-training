import { TestComponents } from "@/components/test-components"

export default function TestPage() {
  return <TestComponents />
}
